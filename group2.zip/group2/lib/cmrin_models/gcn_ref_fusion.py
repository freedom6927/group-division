import torch
import torch.nn as nn
from cmrin_models.model_utils import NormalizeScale
from models.language import RNNEncoder
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math
from cmrin_models.matching import Matching
import pdb


class GCNRefFusion(nn.Module):

    def __init__(self, opt):
        super(GCNRefFusion, self).__init__()

        # language model
        self.rnn_encoder = RNNEncoder(vocab_size=opt['vocab_size'],
                                      word_embedding_size=opt['word_embedding_size'],
                                      hidden_size=opt['rnn_hidden_size'],
                                      bidirectional=opt['bidirectional'] > 0,
                                      input_dropout_p=opt['word_drop_out'],
                                      dropout_p=opt['rnn_drop_out'],
                                      n_layers=opt['rnn_num_layers'],
                                      rnn_type=opt['rnn_type'],
                                      variable_lengths=opt['variable_lengths'] > 0,
                                      pretrain=True)
        dim_word_output = opt['rnn_hidden_size'] * (2 if opt['bidirectional'] else 1)
        num_cls_word = 4
        self.word_judge = nn.Sequential(nn.Linear(dim_word_output, opt['dim_hidden_word_judge']),
                                        nn.ReLU(),
                                        nn.Dropout(opt['word_judge_drop']),
                                        nn.Linear(opt['dim_hidden_word_judge'], num_cls_word),
                                        nn.Softmax(dim=2))

        self.feat_normalizer = NormalizeScale(opt['dim_input_vis_feat'], opt['vis_init_norm'])
        self.label_normalizer = NormalizeScale(opt['rnn_hidden_size'], opt['vis_init_norm'])
        dim_input_vis_feat = opt['dim_input_vis_feat']
        dim_word_embed = opt['word_embedding_size']
        self.word_normalizer = NormalizeScale(dim_word_output, opt['word_init_norm'])
        self.embed_normalizer = NormalizeScale(dim_word_embed, opt['word_init_norm'])
        # absolute location
        self.locate_encoder = LocationEncoder(opt['vis_init_norm'], opt['dim_location'])

        self.nrel_l = opt['num_location_relation']


        # fusion model
        dim_gcn_input = dim_input_vis_feat + dim_word_output

        self.gcn_encoder = GCNFusionEncoder(opt['num_hid_location_gcn'],
                                            opt['num_location_relation'],
                                            opt['gcn_drop_out'],
                                            dim_gcn_input)

        self.matching = Matching(opt['num_hid_location_gcn'][-1]+opt['dim_location'],
                                 dim_word_output, opt['jemb_dim'], opt['jemb_drop_out'])




        #######################################################################ke#####################################################3
        dim_fusion_input = dim_input_vis_feat + dim_word_embed
        self.Tanh = nn.Tanh()

        #language
        self.sub = nn.Linear(dim_word_output, 1)
        self.intra = nn.Linear(dim_word_output, 1)
        self.inter = nn.Linear(dim_word_output, 1)



        # visual 
        # sub,intra,inter
        self.l1 = nn.Linear(dim_word_embed, dim_word_output)
        self.l2 = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.l3 = nn.Linear(dim_word_output, 1)
        



        self.e1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.e2 = nn.Linear(dim_word_output, 1)


        self.feature_convert = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.sentence_fus = nn.Linear(dim_word_embed * 3, dim_word_embed)

        self.fuse_sii = nn.Linear(dim_fusion_input, dim_gcn_input)

        #label
        self.ll1 = nn.Linear(dim_word_embed, opt['rnn_hidden_size'])
        self.ll3 = nn.Linear(opt['rnn_hidden_size'], 1)


        self.le1 = nn.Linear(opt['rnn_hidden_size'] * 2, opt['rnn_hidden_size'])
        self.le2 = nn.Linear(opt['rnn_hidden_size'], 1)

        #self.ee1 = nn.Linear(dim_word_output * 2, dim_word_output)
        #self.ee2 = nn.Linear(dim_word_output, 1)
       
        self.fuse_sii_L = nn.Linear(opt['rnn_hidden_size'] + dim_word_embed, dim_gcn_input)
        #######################################################################ke######################################################


    def forward(self, visual_feature, label_feature, cls, lfeat, lrel, sents):
        # language
        context, hidden, embeded, max_length = self.rnn_encoder(sents)
        input_gcnencoder_sents = sents[:, 0:max_length]
        context_weight = self.word_judge(context)
        is_not_pad_sents = (input_gcnencoder_sents != 0).float()
        context_weight = context_weight * is_not_pad_sents.unsqueeze(2).expand(is_not_pad_sents.size(0),
                                                                               is_not_pad_sents.size(1),
                                                                               context_weight.size(2))




        ###################################################ke#################################################################
        #self-attention language parser
        mask = (1.0 - is_not_pad_sents.float()) * (-1e30)
        sub_score = self.sub(context).squeeze(2) + mask
        intra_score = self.intra(context).squeeze(2) + mask
        inter_score = self.inter(context).squeeze(2) + mask

        
        sub_weight_t = F.softmax(sub_score, dim = 1) 
        intra_weight_t = F.softmax(intra_score, dim = 1) 
        inter_weight_t = F.softmax(inter_score, dim = 1)

        sub_weight = sub_weight_t * is_not_pad_sents.float()
        intra_weight = intra_weight_t * is_not_pad_sents.float()
        inter_weight = inter_weight_t * is_not_pad_sents.float()


        

        sub_weight_sum = torch.sum(sub_weight, dim=1).unsqueeze(1).expand(sub_weight.size(0), sub_weight.size(1))
        sub_weight[sub_weight_sum != 0] = sub_weight[sub_weight_sum != 0] / sub_weight_sum[sub_weight_sum != 0]

        intra_weight_sum = torch.sum(intra_weight, dim=1).unsqueeze(1).expand(intra_weight.size(0), intra_weight.size(1))
        intra_weight[intra_weight_sum != 0] = intra_weight[intra_weight_sum != 0] / intra_weight_sum[intra_weight_sum != 0]

        inter_weight_sum = torch.sum(inter_weight, dim=1).unsqueeze(1).expand(inter_weight.size(0), inter_weight.size(1))
        inter_weight[inter_weight_sum != 0] = inter_weight[inter_weight_sum != 0] / inter_weight_sum[inter_weight_sum != 0]

        #graph
        x = self.feat_normalizer(visual_feature)
        L = self.label_normalizer(label_feature)
        words = self.embed_normalizer(embeded)
        words_context = self.word_normalizer(context)

        #sub, intra, inter
        sub_weight_expand = sub_weight.unsqueeze(2).expand(sub_weight.size(0), sub_weight.size(1), words.size(2))
        intra_weight_expand = intra_weight.unsqueeze(2).expand(intra_weight.size(0), intra_weight.size(1), words.size(2))
        inter_weight_expand = inter_weight.unsqueeze(2).expand(inter_weight.size(0), inter_weight.size(1), words.size(2))
        sub_vector = (sub_weight_expand * words).sum(1)
        intra_vector = (intra_weight_expand * words).sum(1)
        inter_vector = (inter_weight_expand * words).sum(1)

  
        sub_vector_expand = sub_vector.unsqueeze(1).expand(sub_vector.size(0), x.size(1), sub_vector.size(1))
        intra_vector_expand = intra_vector.unsqueeze(1).expand(intra_vector.size(0), x.size(1), intra_vector.size(1))
        inter_vector_expand = inter_vector.unsqueeze(1).expand(inter_vector.size(0), x.size(1), inter_vector.size(1))


        ##pdb.set_trace()
        sentence1 = torch.cat([sub_vector, intra_vector], 1)
        sentence2 = torch.cat([sentence1, inter_vector], 1)
        sentence_fus = self.sentence_fus(sentence2)
        sentence_fus_expand = sentence_fus.unsqueeze(1).expand(sentence_fus.size(0), x.size(1), sentence_fus.size(1))
        is_not_pad_node = (cls != -1.0).float()


        #one-step reasoning
        v_sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + self.l2(x))).squeeze(2)
        v_intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + self.l2(x))).squeeze(2)
        v_inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + self.l2(x))).squeeze(2)

        v_sub_weight = F.softmax(v_sub_score, dim = 1)
        v_intra_weight = F.softmax(v_intra_score, dim = 1)
        v_inter_weight = F.softmax(v_inter_score, dim = 1)

        v_sub_weight = v_sub_weight * is_not_pad_node
        v_intra_weight = v_intra_weight * is_not_pad_node
        v_inter_weight = v_inter_weight * is_not_pad_node

        v_sub_weight_sum = torch.sum(v_sub_weight, dim=1).unsqueeze(1).expand(v_sub_weight.size(0), v_sub_weight.size(1))
        v_sub_weight[v_sub_weight_sum != 0] = v_sub_weight[v_sub_weight_sum != 0] / v_sub_weight_sum[v_sub_weight_sum != 0]

        v_intra_weight_sum = torch.sum(v_intra_weight, dim=1).unsqueeze(1).expand(v_intra_weight.size(0), v_intra_weight.size(1))
        v_intra_weight[v_intra_weight_sum != 0] = v_intra_weight[v_intra_weight_sum != 0] / v_intra_weight_sum[v_intra_weight_sum != 0]

        v_inter_weight_sum = torch.sum(v_inter_weight, dim=1).unsqueeze(1).expand(v_inter_weight.size(0), v_inter_weight.size(1))
        v_inter_weight[v_inter_weight_sum != 0] = v_inter_weight[v_inter_weight_sum != 0] / v_inter_weight_sum[v_inter_weight_sum != 0]



        v_node_weight1 = torch.cat([v_sub_weight.unsqueeze(2), v_intra_weight.unsqueeze(2)], 2)
        v_node_weight_all = torch.cat([v_node_weight1, v_inter_weight.unsqueeze(2)], 2)
        v_wegiht_info = torch.max(v_node_weight_all, 2)
        v_node_weight_type = v_wegiht_info[1]
        v_i_node_weight = v_wegiht_info[0]


        #visual node defination
        v_sub_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
        v_intra_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
        v_inter_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
        #pdb.set_trace()
        for i in range(0, v_node_weight_type.size(0)):
            for j in range(0, v_node_weight_type.size(1)):
                if v_node_weight_type[i, j] == 0:
                    v_sub_selection[i, j] = 1
                if v_node_weight_type[i, j] == 1:
                    v_intra_selection[i, j] = 1
                if v_node_weight_type[i, j] == 2:
                    v_inter_selection[i, j] = 1
        
        #pdb.set_trace()
        v_sub_vector_selection = sub_vector_expand * v_sub_selection.unsqueeze(2).expand(v_sub_selection.size(0), v_sub_selection.size(1), sub_vector.size(1))
        v_intra_vector_selection = intra_vector_expand * v_intra_selection.unsqueeze(2).expand(v_intra_selection.size(0), v_intra_selection.size(1), intra_vector.size(1))
        v_inter_vector_selection = inter_vector_expand * v_inter_selection.unsqueeze(2).expand(v_inter_selection.size(0), v_inter_selection.size(1), inter_vector.size(1))
        v_vector_selection = v_sub_vector_selection + v_intra_vector_selection + v_inter_vector_selection

        x_sii = torch.cat([x, v_vector_selection], dim = 2)
        x_sii = x_sii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), x_sii.size(2)))
        x_i = self.fuse_sii(x_sii)

        #my visual edge weight
        ##pdb.set_trace()
        
        visual_edge_score = torch.zeros((lrel.size(0), lrel.size(1), lrel.size(2))).cuda()
        #pdb.set_trace()
        for i in range(0, x.size(1)):
            ##pdb.set_trace()
            e_x_i = self.feature_convert(x[:,i,:])
            x_convert = self.feature_convert(x)
            e_x_i_expand = e_x_i.unsqueeze(1).expand(e_x_i.size(0), x.size(1), e_x_i.size(1))
            x_c_i = torch.cat([x_convert, e_x_i_expand], 2)
            x_fus_i = self.Tanh(self.e1(x_c_i))
            visual_edge_score_i = self.e2(x_fus_i).squeeze(2)
            visual_edge_score[:,:,i] = visual_edge_score_i
        #pdb.set_trace()
        visual_edge_score_norm = F.softmax(visual_edge_score, dim = 2)
        is_not_pad_node_expand = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), is_not_pad_node.size(1))
        visual_edge_weights = visual_edge_score_norm * is_not_pad_node_expand


        # my label node weight
        l_sub_score = self.ll3(self.Tanh(self.ll1(sub_vector_expand) + L)).squeeze(2)
        l_intra_score = self.ll3(self.Tanh(self.ll1(intra_vector_expand) + L)).squeeze(2)
        l_inter_score = self.ll3(self.Tanh(self.ll1(inter_vector_expand) + L)).squeeze(2)

        l_sub_weight = F.softmax(l_sub_score, dim = 1)
        l_intra_weight = F.softmax(l_intra_score, dim = 1)
        l_inter_weight = F.softmax(l_inter_score, dim = 1)

        l_sub_weight = l_sub_weight * is_not_pad_node
        l_intra_weight = l_intra_weight * is_not_pad_node
        l_inter_weight = l_inter_weight * is_not_pad_node

        l_sub_weight_sum = torch.sum(l_sub_weight, dim=1).unsqueeze(1).expand(l_sub_weight.size(0), l_sub_weight.size(1))
        l_sub_weight[l_sub_weight_sum != 0] = l_sub_weight[l_sub_weight_sum != 0] / l_sub_weight_sum[l_sub_weight_sum != 0]

        l_intra_weight_sum = torch.sum(l_intra_weight, dim=1).unsqueeze(1).expand(l_intra_weight.size(0), l_intra_weight.size(1))
        l_intra_weight[l_intra_weight_sum != 0] = l_intra_weight[l_intra_weight_sum != 0] / l_intra_weight_sum[l_intra_weight_sum != 0]

        l_inter_weight_sum = torch.sum(l_inter_weight, dim=1).unsqueeze(1).expand(l_inter_weight.size(0), l_inter_weight.size(1))
        l_inter_weight[l_inter_weight_sum != 0] = l_inter_weight[l_inter_weight_sum != 0] / l_inter_weight_sum[l_inter_weight_sum != 0]

        l_node_weight1 = torch.cat([l_sub_weight.unsqueeze(2), l_intra_weight.unsqueeze(2)], 2)
        l_node_weight_all = torch.cat([l_node_weight1, l_inter_weight.unsqueeze(2)], 2)
        ##pdb.set_trace()
        l_wegiht_info = torch.max(l_node_weight_all, 2)
        l_node_weight_type = l_wegiht_info[1]
        l_i_node_weight = l_wegiht_info[0]


        # my label node definition

        l_sub_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
        l_intra_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
        l_inter_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
        #pdb.set_trace()
        for i in range(0, l_node_weight_type.size(0)):
            for j in range(0, l_node_weight_type.size(1)):
                if l_node_weight_type[i, j] == 0:
                    l_sub_selection[i, j] = 1
                if l_node_weight_type[i, j] == 1:
                    l_intra_selection[i, j] = 1
                if l_node_weight_type[i, j] == 2:
                    l_inter_selection[i, j] = 1

        #pdb.set_trace()
        l_sub_vector_selection = sub_vector_expand * l_sub_selection.unsqueeze(2).expand(l_sub_selection.size(0), l_sub_selection.size(1), sub_vector.size(1))
        l_intra_vector_selection = intra_vector_expand * l_intra_selection.unsqueeze(2).expand(l_intra_selection.size(0), l_intra_selection.size(1), intra_vector.size(1))
        l_inter_vector_selection = inter_vector_expand * l_inter_selection.unsqueeze(2).expand(l_inter_selection.size(0), l_inter_selection.size(1), inter_vector.size(1))
        l_vector_selection = l_sub_vector_selection + l_intra_vector_selection + l_inter_vector_selection




        l_ii = torch.cat([L, l_vector_selection], dim = 2)
        l_ii = l_ii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), l_ii.size(2)))
        l_i = self.fuse_sii_L(l_ii)

        # my label edge weight

        L_edge_score = torch.zeros((lrel.size(0), lrel.size(1), lrel.size(2))).cuda()
        #pdb.set_trace()
        for i in range(0, L.size(1)):
            ##pdb.set_trace()
            e_L_i = L[:,i,:]
            e_L_i_expand = e_L_i.unsqueeze(1).expand(e_L_i.size(0), L.size(1), e_L_i.size(1))
            L_c_i = torch.cat([L, e_L_i_expand], 2)
            L_fus_i = self.Tanh(self.le1(L_c_i))
            L_edge_score_i = self.le2(L_fus_i).squeeze(2)
            L_edge_score[:,:,i] = L_edge_score_i
        
        L_edge_score_norm = F.softmax(L_edge_score, dim = 2)
        label_edge_weights = L_edge_score_norm * is_not_pad_node_expand
        #pdb.set_trace()

        ###################################################ke#################################################################

        # obtain edge gate
        '''
        word_edge_weights_expand = context_weight[:, :, 0].unsqueeze(2).expand(context_weight.size(0),
                                                                               context_weight.size(1),
                                                                               self.nrel_l)
        words_input_edge_gate = words
        edge_type_weight = self.edge_gate(words_input_edge_gate)
        edge_weight_per_type_per_word = edge_type_weight * word_edge_weights_expand
        edge_weight_per_type_per_sent = torch.sum(edge_weight_per_type_per_word, 1)
        '''
        # obtain note gate
        '''
        words_expand = words.unsqueeze(2).expand(words.size(0), words.size(1), x.size(1), words.size(2))
        x_expand = x.unsqueeze(1).expand(x.size(0), words.size(1), x.size(1), x.size(2))
        attn_word_node = self.node_word_match(torch.cat([words_expand, x_expand], 3)).squeeze(3)
        is_not_pad_node = (cls != -1.0).float()
        attn_word_node = attn_word_node * (is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0),
                                                                               attn_word_node.size(1),
                                                                               is_not_pad_node.size(1)))
        attn_word_node_sum = attn_word_node.sum(2).unsqueeze(2).expand(attn_word_node.size(0),
                                                                       attn_word_node.size(1),
                                                                       attn_word_node.size(2))
        attn_word_node[attn_word_node_sum != 0] = attn_word_node[attn_word_node_sum != 0] / \
                                                  attn_word_node_sum[attn_word_node_sum != 0]
        word_node_weights_expand = context_weight[:, :, 1].unsqueeze(2).expand(context_weight.size(0),
                                                                               context_weight.size(1),
                                                                               x.size(1))
        node_weight_per_word = attn_word_node * word_node_weights_expand
        word_feat_per_node = torch.bmm(node_weight_per_word.transpose(1, 2), words)
        node_weight_per_sent = torch.sum(node_weight_per_word, 1)

        vis_feat_per_node = x
        '''
        # visual location
        location_feature = self.locate_encoder(lfeat)  # num_image, num_box, dim_location_feature
        '''
        fusion_feat_per_node = torch.cat([word_feat_per_node, vis_feat_per_node], dim=2)
        '''
        visual_gcn_feature = self.gcn_encoder(x_i, cls, lrel, visual_edge_weights, v_i_node_weight, sub_vector_expand, intra_vector_expand, inter_vector_expand, sentence_fus_expand, is_not_pad_node)
        label_gcn_feature = self.gcn_encoder(l_i, cls, lrel, label_edge_weights, l_i_node_weight, sub_vector_expand, intra_vector_expand, inter_vector_expand, sentence_fus_expand, is_not_pad_node)

        # judge word context
        attn = torch.sum(context_weight[:, :, 0:3], 2)
        attn_sum = attn.sum(1).unsqueeze(1).expand(attn.size(0), attn.size(1))
        attn[attn_sum != 0] = attn[attn_sum != 0] / (attn_sum[attn_sum != 0])
        attn3 = attn.unsqueeze(1)
        lang_cxt = torch.bmm(attn3, words_context)
        lang_cxt = lang_cxt.squeeze(1)

        # matching
        vis_cxt = torch.cat([visual_gcn_feature, location_feature], dim=2)
        lab_cxt = torch.cat([label_gcn_feature, location_feature], dim=2)
        v_score_cos = self.matching(vis_cxt, lang_cxt)
        l_score_cos = self.matching(lab_cxt, lang_cxt)
        score_cos = v_score_cos + l_score_cos
        return score_cos


class LocationEncoder(nn.Module):
    def __init__(self, init_norm, dim):
        super(LocationEncoder, self).__init__()
        self.lfeat_normalizer = NormalizeScale(5, init_norm)
        self.fc = nn.Linear(5, dim)

    def forward(self, lfeats):
        loc_feat = self.lfeat_normalizer(lfeats)
        output = self.fc(loc_feat)
        return output


class GCNFusionEncoder(nn.Module):
    def __init__(self, nhid_l, nrel_l, dropout, dim_input_vis):
        super(GCNFusionEncoder, self).__init__()
        self.nrel_l = nrel_l

        self.l_gcn = nn.ModuleList([GCNFusionUnit(dim_input_vis, nhid_l[0], nrel_l)])
        for i in range(len(nhid_l)-1):
            self.l_gcn.append(GCNFusionUnit(nhid_l[i], nhid_l[i+1], nrel_l))
        self.dropout = dropout

        ###########################################ke############################
        dim_word_embed = 300
        dim_input_vis_feat = 1024
        self.Tanh = nn.Tanh()
        self.l1 = nn.Linear(dim_word_embed, dim_input_vis_feat)
        self.l3 = nn.Linear(dim_input_vis_feat, 1)
        
        self.e1 = nn.Linear(dim_input_vis_feat * 2, dim_input_vis_feat)
        self.e2 = nn.Linear(dim_input_vis_feat, 1)
         ###########################################ke############################

    def forward(self, x, cls, rel_l, edge_weight, node_weight, sub_vector_expand, intra_vector_expand, inter_vector_expand, sentence_fus_expand, is_not_pad_node):
        #pdb.set_trace()
        #pdb.set_trace()
        for j in range(0, len(self.l_gcn)):
            if j == 0:
                xl = F.relu(self.l_gcn[j](x, cls, rel_l, edge_weight, node_weight))
            else:
                is_not_pad_node_expand = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), is_not_pad_node.size(1))
                #node weight
                sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + xl)).squeeze(2)
                intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + xl)).squeeze(2)
                inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + xl)).squeeze(2)

                sub_weight = F.softmax(sub_score, dim = 1)
                intra_weight = F.softmax(intra_score, dim = 1)
                inter_weight = F.softmax(inter_score, dim = 1)

                sub_weight = sub_weight * is_not_pad_node
                intra_weight = intra_weight * is_not_pad_node
                inter_weight = inter_weight * is_not_pad_node

                sub_weight_sum = torch.sum(sub_weight, dim=1).unsqueeze(1).expand(sub_weight.size(0), sub_weight.size(1))
                sub_weight[sub_weight_sum != 0] = sub_weight[sub_weight_sum != 0] / sub_weight_sum[sub_weight_sum != 0]

                intra_weight_sum = torch.sum(intra_weight, dim=1).unsqueeze(1).expand(intra_weight.size(0), intra_weight.size(1))
                intra_weight[intra_weight_sum != 0] = intra_weight[intra_weight_sum != 0] / intra_weight_sum[intra_weight_sum != 0]

                inter_weight_sum = torch.sum(inter_weight, dim=1).unsqueeze(1).expand(inter_weight.size(0), inter_weight.size(1))
                inter_weight[inter_weight_sum != 0] = inter_weight[inter_weight_sum != 0] / inter_weight_sum[inter_weight_sum != 0]

                node_weight1 = torch.cat([sub_weight.unsqueeze(2), intra_weight.unsqueeze(2)], 2)
                node_weight_all = torch.cat([node_weight1, inter_weight.unsqueeze(2)], 2)
                wegiht_info = torch.max(node_weight_all, 2)
                i_node_weight = wegiht_info[0]

                #edge weight
                edge_score = torch.zeros((rel_l.size(0), rel_l.size(1), rel_l.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, xl.size(1)):
                    ##pdb.set_trace()
                    x_ii_expand = xl[:,i,:].unsqueeze(1).expand(xl[:,i,:].size(0), xl.size(1), xl[:,i,:].size(1))
                    x_c_i = torch.cat([xl, x_ii_expand], 2)
                    x_fus_i = self.e1(x_c_i)

                    edge_score_i = self.e2(self.Tanh(self.l1(sentence_fus_expand) + x_fus_i)).squeeze(2)
                    edge_score[:,:,i] = edge_score_i
                
                edge_score = F.softmax(edge_score, dim = 2)
                edge_weight = is_not_pad_node_expand * edge_score
                xl = F.relu(self.l_gcn[j](xl, cls, rel_l, edge_weight, i_node_weight))
                xl = F.dropout(xl, self.dropout, training=self.training)

        return xl


class GCNFusionUnit(nn.Module):
    def __init__(self, num_in_vis, num_out, num_type):
        super(GCNFusionUnit, self).__init__()
        self.in_features = num_in_vis
        self.out_features = num_out
        self.num_type = num_type
        self.w1 = Parameter(torch.FloatTensor(num_in_vis, num_out))
        self.w2 = Parameter(torch.FloatTensor(num_in_vis, num_out))
        self.w3 = Parameter(torch.FloatTensor(num_in_vis, num_out))
        self.rel_bias = Parameter(torch.FloatTensor(num_type, num_out))

        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.w1.size(1))
        self.w1.data.uniform_(-stdv, stdv)
        self.w2.data.uniform_(-stdv, stdv)
        self.w3.data.uniform_(-stdv, stdv)
        self.rel_bias.data.uniform_(-stdv, stdv)

    def forward(self, x, cls, rel, edge_weight, node_weight):
        #pdb.set_trace()
        rel.requires_grad = False
        x3 = torch.matmul(x, self.w3)
        x = node_weight.unsqueeze(2).expand(node_weight.size(0),
                                                     node_weight.size(1),
                                                     x.size(2)) * x
        x1 = torch.matmul(x, self.w1)
        x2 = torch.matmul(x, self.w2)
        x1_t = torch.zeros((x1.size(0), x1.size(1), x1.size(2)), requires_grad=False).cuda()
        x2_t = torch.zeros((x2.size(0), x2.size(1), x2.size(2)), requires_grad=False).cuda()

        for i in range(self.num_type):
            adj1_un = (rel == i).detach()
            adj2_un = adj1_un.transpose(2, 1)
            adj1 = adj2_un.float()
            adj2 = adj1_un.float()
            gate_matrix_1 = edge_weight

            gate_adj1 = gate_matrix_1 * adj1
            x1_t = x1_t + torch.bmm(gate_adj1, x1) + \
                                    self.rel_bias[i].unsqueeze(0).unsqueeze(1).expand(adj1.size(0),
                                                                                      adj1.size(1),
                                                                                      self.rel_bias.size(1)) * \
                                    gate_adj1.sum(2).unsqueeze(2).expand(adj1.size(0), adj1.size(1),
                                                                         self.rel_bias.size(1))

            gate_matrix_2 = edge_weight
            gate_adj2 = gate_matrix_2 * adj2
            x2_t = x2_t + torch.bmm(gate_adj2, x2) + \
                                    self.rel_bias[i].unsqueeze(0).unsqueeze(1).expand(adj2.size(0),
                                                                                      adj2.size(1),
                                                                                      self.rel_bias.size(1)) * \
                                    gate_adj2.sum(2).unsqueeze(2).expand(adj2.size(0), adj2.size(1),
                                                                         self.rel_bias.size(1))

        adj3 = torch.ones((x3.size(0), x3.size(1)), requires_grad=False).cuda()
        adj3[cls == -1] = 0.0
        adj3 = adj3.unsqueeze(2)
        adj3_weight = adj3
        x3_t = x3 * adj3_weight.expand(adj3.size(0), adj3.size(1), x3.size(2))

        x_new = x1_t + x2_t + x3_t

        return x_new

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + '->' \
               + str(self.out_features) + ')'
