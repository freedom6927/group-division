import torch
import torch.nn as nn
from cmrin_models.model_utils import NormalizeScale
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math
import pdb


class GraphR(nn.Module):
    def __init__(self, opt):
        super(GraphR, self).__init__()

        dim_word_embed = opt['word_embedding_size']
        dim_word_output = opt['rnn_hidden_size'] * (2 if opt['bidirectional'] else 1)

        self.feat_normalizer = NormalizeScale(opt['dim_input_vis_feat'], opt['vis_init_norm'])
        self.label_normalizer = NormalizeScale(opt['rnn_hidden_size'], opt['vis_init_norm'])
        dim_input_vis_feat = opt['dim_input_vis_feat']
        self.word_normalizer = NormalizeScale(dim_word_embed, opt['word_init_norm'])

        self.nrel_l = opt['num_location_relation']
        

        self.T_ctrl = opt['T_ctrl']

        dim_reason = opt['dim_reason']
        # fusion model
        dim_fusion_input = dim_input_vis_feat + dim_word_embed
        self.fuse_fc = nn.Linear(dim_fusion_input, dim_reason)
        self.fuse_sii = nn.Linear(dim_fusion_input, dim_reason)
        self.fuse_sii_L = nn.Linear(opt['rnn_hidden_size'] + dim_word_output, dim_reason)


        #########################################ke############################################################3
        self.Tanh = nn.Tanh()

        #sentence_visul fusion
        self.sen1 = nn.Linear(dim_word_output, dim_word_output)
        self.sen2 = nn.Linear(dim_word_output, dim_word_output)
        self.sen3 = nn.Linear(dim_word_output, 1)
        self.entire = nn.Linear(dim_word_output + dim_word_embed, dim_word_output)
        # visual
        self.sub_v_graph_nodes = nn.Linear(dim_word_output, 1)


        # sub,intra,inter
        self.l1 = nn.Linear(dim_word_embed, dim_word_output)
        self.l2 = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.l3 = nn.Linear(dim_word_output, 1)
        



        self.e1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.e2 = nn.Linear(dim_word_output, 1)

        self.feature_convert = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.sentence_fus = nn.Linear(dim_word_embed * 3, dim_word_embed)


        #label
        self.sub_L_graph_nodes = nn.Linear(dim_word_output, 1)

        #self.ll1 = nn.Linear(dim_word_embed, opt['rnn_hidden_size'])
        #self.ll3 = nn.Linear(opt['rnn_hidden_size'], 1)


        #self.le1 = nn.Linear(opt['rnn_hidden_size'] * 2, opt['rnn_hidden_size'])
        #self.le2 = nn.Linear(opt['rnn_hidden_size'], 1)

        self.ee1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.ee2 = nn.Linear(dim_word_output, 1)

        #self.clip_trans = nn.Linear(opt['rnn_hidden_size'], dim_input_vis_feat)

        #########################################ke############################################################3

        # update feature
        self.w1 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.w3 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.rel_bias = Parameter(torch.FloatTensor(self.nrel_l, dim_reason))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.w1.size(1))
        self.w1.data.uniform_(-stdv, stdv)
        self.w3.data.uniform_(-stdv, stdv)
        self.rel_bias.data.uniform_(-stdv, stdv)

    def forward(self, visual_feature, label_feature, sub_weight, intra_weight, inter_weight, sentence_encoding, embed, cls, rel):
        #pdb.set_trace()
        #clip_feature = self.clip_trans(visual_feature)
        #x = self.feat_normalizer(clip_feature)
        x = self.feat_normalizer(visual_feature)
        L = self.label_normalizer(label_feature)
        words = self.word_normalizer(embed)
        
        #########################################ke############################################################3

        #sub, intra, inter
        sub_weight_expand = sub_weight.unsqueeze(2).expand(sub_weight.size(0), sub_weight.size(1), words.size(2))
        intra_weight_expand = intra_weight.unsqueeze(2).expand(intra_weight.size(0), intra_weight.size(1), words.size(2))
        inter_weight_expand = inter_weight.unsqueeze(2).expand(inter_weight.size(0), inter_weight.size(1), words.size(2))
        sub_vector = (sub_weight_expand * words).sum(1)
        intra_vector = (intra_weight_expand * words).sum(1)
        inter_vector = (inter_weight_expand * words).sum(1)

  
        sub_vector_expand = sub_vector.unsqueeze(1).expand(sub_vector.size(0), x.size(1), sub_vector.size(1))
        intra_vector_expand = intra_vector.unsqueeze(1).expand(intra_vector.size(0), x.size(1), intra_vector.size(1))
        inter_vector_expand = inter_vector.unsqueeze(1).expand(inter_vector.size(0), x.size(1), inter_vector.size(1))


        #pdb.set_trace()
        sentence1 = torch.cat([sub_vector, intra_vector], 1)
        sentence2 = torch.cat([sentence1, inter_vector], 1)
        sentence_fus = self.sentence_fus(sentence2)
        sentence_fus_expand = sentence_fus.unsqueeze(1).expand(sentence_fus.size(0), x.size(1), sentence_fus.size(1))
        is_not_pad_node = (cls != -1.0).float()


        #valid count
        valid_node_count = torch.zeros((is_not_pad_node.size(0)), requires_grad=False).cuda()

        for i in range(0, is_not_pad_node.size(0)):
            for j in range(0, is_not_pad_node.size(1)):
                if is_not_pad_node[i][j] == 1:
                    valid_node_count[i] = valid_node_count[i] + 1
            
        #########################################ke############################################################3
        #group division
        #weight
        v_sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + self.l2(x))).squeeze(2)
        v_intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + self.l2(x))).squeeze(2)
        v_inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + self.l2(x))).squeeze(2)

        v_sub_weight = F.softmax(v_sub_score, dim = 1)
        v_intra_weight = F.softmax(v_intra_score, dim = 1)
        v_inter_weight = F.softmax(v_inter_score, dim = 1)

        v_sub_weight = v_sub_weight * is_not_pad_node
        v_intra_weight = v_intra_weight * is_not_pad_node
        v_inter_weight = v_inter_weight * is_not_pad_node

        v_sub_weight_sum = torch.sum(v_sub_weight, dim=1).unsqueeze(1).expand(v_sub_weight.size(0), v_sub_weight.size(1))
        v_sub_weight[v_sub_weight_sum != 0] = v_sub_weight[v_sub_weight_sum != 0] / v_sub_weight_sum[v_sub_weight_sum != 0]

        v_intra_weight_sum = torch.sum(v_intra_weight, dim=1).unsqueeze(1).expand(v_intra_weight.size(0), v_intra_weight.size(1))
        v_intra_weight[v_intra_weight_sum != 0] = v_intra_weight[v_intra_weight_sum != 0] / v_intra_weight_sum[v_intra_weight_sum != 0]

        v_inter_weight_sum = torch.sum(v_inter_weight, dim=1).unsqueeze(1).expand(v_inter_weight.size(0), v_inter_weight.size(1))
        v_inter_weight[v_inter_weight_sum != 0] = v_inter_weight[v_inter_weight_sum != 0] / v_inter_weight_sum[v_inter_weight_sum != 0]

        #sort
        coarse_selection = torch.floor(max(is_not_pad_node.sum(1))*2/3)
        #sub_weight
        #pdb.set_trace()
        coarse_sub_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
        coarse_sub_sort_res = torch.sort(v_sub_weight, dim=1, descending=True)

        for i in range(0, coarse_sub_is_not_pad_node.size(0)):
            for j in range(0, int(coarse_selection)):
                coarse_sub_is_not_pad_node[i][coarse_sub_sort_res[1][i][j]] = 1

        v_sub_weight = v_sub_weight * coarse_sub_is_not_pad_node


        #pdb.set_trace()
        #sub_graph_node
        sub_x_sii = torch.cat([x, sub_vector_expand], dim = 2)
        sub_x_sii = sub_x_sii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), sub_x_sii .size(2)))
        sub_x_i = self.fuse_sii(sub_x_sii)

       
        #intra_weight
        coarse_intra_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
        coarse_intra_sort_res = torch.sort(v_intra_weight, dim=1, descending=True)
        for i in range(0, coarse_intra_is_not_pad_node.size(0)):
            for j in range(0, int(coarse_selection)):
                coarse_intra_is_not_pad_node[i][coarse_intra_sort_res[1][i][j]] = 1

        v_sub_weight = v_sub_weight * coarse_intra_is_not_pad_node


        #intra_graph_node
        intra_x_sii = torch.cat([x, intra_vector_expand], dim = 2)
        intra_x_sii = intra_x_sii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), intra_x_sii.size(2)))
        intra_x_i = self.fuse_sii(intra_x_sii)

        #inter_weight
        coarse_inter_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
        coarse_inter_sort_res = torch.sort(v_inter_weight, dim=1, descending=True)
  
        coarse_inter_sort_res = torch.sort(v_inter_weight, dim=1, descending=True)
        for i in range(0, coarse_inter_is_not_pad_node.size(0)):
            for j in range(0, int(coarse_selection)):
                coarse_inter_is_not_pad_node[i][coarse_inter_sort_res[1][i][j]] = 1

        v_sub_weight = v_sub_weight * coarse_inter_is_not_pad_node

        #inter_graph_node
        inter_x_sii = torch.cat([x, inter_vector_expand], dim = 2)
        inter_x_sii = inter_x_sii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), inter_x_sii.size(2)))
        inter_x_i = self.fuse_sii(inter_x_sii)
        

        #three_graph_edge_weight
        visual_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(2))).cuda()
        #pdb.set_trace()
        for i in range(0, x.size(1)):
            ##pdb.set_trace()
            e_x_i = self.feature_convert(x[:,i,:])
            x_convert = self.feature_convert(x)
            e_x_i_expand = e_x_i.unsqueeze(1).expand(e_x_i.size(0), x.size(1), e_x_i.size(1))
            x_c_i = torch.cat([x_convert, e_x_i_expand], 2)
            x_fus_i = self.Tanh(self.e1(x_c_i))
            visual_edge_score_i = self.e2(x_fus_i).squeeze(2)
            visual_edge_score[:,:,i] = visual_edge_score_i
       
        visual_edge_score_norm = F.softmax(visual_edge_score, dim = 2)
        is_not_pad_node_expand = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), is_not_pad_node.size(1))
        visual_edge_weights = visual_edge_score_norm * is_not_pad_node_expand

        #pdb.set_trace()
        sub_x_node_gate, sub_x_i = self.go_node(v_sub_weight, sub_x_i)
        intra_x_node_gate, intra_x_i = self.go_node(v_intra_weight, intra_x_i)
        inter_x_node_gate, inter_x_i = self.go_node(v_inter_weight, inter_x_i)

        sub_node_gate, sub_x_i = self.go(sub_x_node_gate, v_sub_weight, sub_x_i, visual_edge_weights, cls, rel)
        intra_node_gate, intra_x_i = self.go(intra_x_node_gate, v_intra_weight, intra_x_i, visual_edge_weights, cls, rel)
        inter_node_gate, inter_x_i = self.go(inter_x_node_gate, v_inter_weight, inter_x_i, visual_edge_weights, cls, rel)
        #pdb.set_trace()

        #Filtering based reasoning
        x_node_gate = torch.zeros((x.size(0), x.size(1)), requires_grad=False).cuda()
        l_node_gate = torch.zeros((L.size(0), L.size(1)), requires_grad=False).cuda()
        # edge_type_gate = torch.zeros((edge_type_weight.size(0), edge_type_weight.size(2)), requires_grad=False).cuda()
        x_list = []
        l_list = []

        sentence_encoding_expand = sentence_encoding.unsqueeze(1).expand(sentence_encoding.size(0), x.size(1), sentence_encoding.size(1))
        for T in range(self.T_ctrl):
            #pdb.set_trace()
            if T == 0:
                #pdb.set_trace()
                sen_sub_score = self.sen3(self.Tanh(self.sen1(sub_x_i) + self.sen2(sentence_encoding_expand))).squeeze(2)
                sen_intra_score = self.sen3(self.Tanh(self.sen1(intra_x_i) + self.sen2(sentence_encoding_expand))).squeeze(2)
                sen_inter_score = self.sen3(self.Tanh(self.sen1(inter_x_i) + self.sen2(sentence_encoding_expand))).squeeze(2)
                
                cat_score = torch.cat([sen_sub_score.unsqueeze(1), sen_intra_score.unsqueeze(1), sen_inter_score.unsqueeze(1)], dim = 1)
                selected_notes = cat_score.argmax(dim=1)
                #fus_score = sen_sub_score + sen_intra_score + sen_inter_score
                #new sub-graph construction
                valid_notes = torch.ones((cat_score.size(0), cat_score.size(1), cat_score.size(2)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, selected_notes.size(0)):
                    for j in range(0, selected_notes.size(1)):
                        if selected_notes[i][j] == 0:
                            valid_notes[i][1][j] = 0
                            valid_notes[i][2][j] = 0
                        
                        if selected_notes[i][j] == 1:
                            valid_notes[i][0][j] = 0
                            valid_notes[i][2][j] = 0

                        if selected_notes[i][j] == 2:
                            valid_notes[i][0][j] = 0
                            valid_notes[i][1][j] = 0
                #pdb.set_trace()
                #visual sub-graph node
                mid_sub_x_i = sub_x_i * valid_notes[:,0,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), sub_x_i.size(2))
                mid_intra_x_i = intra_x_i * valid_notes[:,1,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), intra_x_i.size(2))
                mid_inter_x_i = inter_x_i * valid_notes[:,2,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), inter_x_i.size(2))
                sub_v_node_features = mid_sub_x_i + mid_intra_x_i + mid_inter_x_i

                mid_sub_node_gate = sub_node_gate * valid_notes[:,0,:]
                mid_intra_node_gate = intra_node_gate * valid_notes[:,1,:]
                mid_inter_node_gate = inter_node_gate * valid_notes[:,2,:]
                v_node_gate = mid_sub_node_gate + mid_intra_node_gate + mid_inter_node_gate

                x_list.append(sub_v_node_features)


                #label sub-graph node
                mid_sub_L_i = L * valid_notes[:,0,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), L.size(2))
                mid_intra_L_i = L * valid_notes[:,1,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), L.size(2))
                mid_inter_L_i = L * valid_notes[:,2,:].unsqueeze(2).expand(valid_notes.size(0), valid_notes.size(2), L.size(2))
                mid_sub_L_node_features = mid_sub_L_i + mid_intra_L_i + mid_inter_L_i


                
                #pdb.set_trace()
                sub_L_node_features = self.fuse_sii_L(torch.cat([mid_sub_L_node_features, sentence_encoding_expand], dim = 2))


                entire_sentence = torch.cat([sentence_encoding_expand, sentence_fus_expand], dim = 2)

                #visual node weight
                v_subgraph_score = self.sub_v_graph_nodes(self.Tanh(self.entire(entire_sentence) + sub_v_node_features)).squeeze(2)
                v_subgraph_weight = F.softmax(v_subgraph_score, dim = 1)
                v_subgraph_weight = v_subgraph_weight * is_not_pad_node
                v_subgraph_weight_sum = torch.sum(v_subgraph_weight, dim=1).unsqueeze(1).expand(v_subgraph_weight.size(0), v_subgraph_weight.size(1))
                v_subgraph_weight[v_subgraph_weight_sum != 0] = v_subgraph_weight[v_subgraph_weight_sum != 0] / v_subgraph_weight_sum[v_subgraph_weight_sum != 0]

                #label node weight
                l_subgraph_score = self.sub_L_graph_nodes(self.Tanh(self.entire(entire_sentence) + sub_L_node_features)).squeeze(2)
                l_subgraph_weight = F.softmax(l_subgraph_score, dim = 1)
                l_subgraph_weight = l_subgraph_weight * is_not_pad_node
                l_subgraph_weight_sum = torch.sum(l_subgraph_weight, dim=1).unsqueeze(1).expand(l_subgraph_weight.size(0), l_subgraph_weight.size(1))
                l_subgraph_weight[l_subgraph_weight_sum != 0] = l_subgraph_weight[l_subgraph_weight_sum != 0] / l_subgraph_weight_sum[l_subgraph_weight_sum != 0]


                l_node_gate, L_feature_i = self.go_node(l_subgraph_weight, sub_L_node_features)
                l_list.append(L_feature_i)

                #pdb.set_trace()
                #filtering
                fine_selection = torch.floor(coarse_selection * 1/2)
                #visual
                v_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
                v_sub_sort_res = torch.sort(v_subgraph_weight, dim=1, descending=True)
                for i in range(0, v_is_not_pad_node.size(0)):
                    for j in range(0, int(fine_selection)):
                        v_is_not_pad_node[i][v_sub_sort_res[1][i][j]] = 1

                v_subgraph_weight = v_subgraph_weight * v_is_not_pad_node


                #label
                l_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
                l_sub_sort_res = torch.sort(l_subgraph_weight, dim=1, descending=True)
                for i in range(0, l_is_not_pad_node.size(0)):
                    for j in range(0, int(fine_selection)):
                        l_is_not_pad_node[i][l_sub_sort_res[1][i][j]] = 1

                l_subgraph_weight = l_subgraph_weight * l_is_not_pad_node
                #pdb.set_trace()

                #visual edge weight
                v_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, x_list[-1].size(1)):
                    ##pdb.set_trace()
                    x_ii_expand = x_list[-1][:,i,:].unsqueeze(1).expand(x_list[-1][:,i,:].size(0), x_list[-1].size(1), x_list[-1][:,i,:].size(1))
                    x_c_i = torch.cat([x_list[-1], x_ii_expand], 2)
                    x_fus_i = self.e1(x_c_i)

                    v_edge_score_i = self.e2(self.Tanh(self.l1(sentence_fus_expand) + x_fus_i)).squeeze(2)
                    v_edge_score[:,:,i] = v_edge_score_i
                
                v_edge_score = F.softmax(v_edge_score, dim = 2)
                v_edge_weight = is_not_pad_node_expand * v_edge_score

                #pdb.set_trace()
                #label edge weight
                l_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, l_list[-1].size(1)):
                    ##pdb.set_trace()
                    l_ii_expand = l_list[-1][:,i,:].unsqueeze(1).expand(l_list[-1][:,i,:].size(0), l_list[-1].size(1), l_list[-1][:,i,:].size(1))
                    l_c_i = torch.cat([l_list[-1], l_ii_expand], 2)
                    l_fus_i = self.ee1(l_c_i)

                    l_edge_score_i = self.ee2(self.Tanh(self.l1(sentence_fus_expand) + l_fus_i)).squeeze(2)
                    l_edge_score[:,:,i] = l_edge_score_i
                
                l_edge_score = F.softmax(l_edge_score, dim = 2)
                l_edge_weight = is_not_pad_node_expand * l_edge_score
                #pdb.set_trace()

                v_node_gate, v_i_feature = self.go(v_node_gate, v_subgraph_weight, x_list[-1], v_edge_weight, cls, rel)
                l_node_gate, l_i_feature = self.go(l_node_gate, l_subgraph_weight, l_list[-1], l_edge_weight, cls, rel)
                x_list.append(v_i_feature)
                l_list.append(l_i_feature)

            else:
                v_subgraph_score = self.sub_v_graph_nodes(self.Tanh(self.entire(entire_sentence) + x_list[-1])).squeeze(2)
                v_subgraph_weight = F.softmax(v_subgraph_score, dim = 1)
                v_subgraph_weight = v_subgraph_weight * is_not_pad_node
                v_subgraph_weight_sum = torch.sum(v_subgraph_weight, dim=1).unsqueeze(1).expand(v_subgraph_weight.size(0), v_subgraph_weight.size(1))
                v_subgraph_weight[v_subgraph_weight_sum != 0] = v_subgraph_weight[v_subgraph_weight_sum != 0] / v_subgraph_weight_sum[v_subgraph_weight_sum != 0]

                #label node weight
                l_subgraph_score = self.sub_L_graph_nodes(self.Tanh(self.entire(entire_sentence) + l_list[-1])).squeeze(2)
                l_subgraph_weight = F.softmax(l_subgraph_score, dim = 1)
                l_subgraph_weight = l_subgraph_weight * is_not_pad_node
                l_subgraph_weight_sum = torch.sum(l_subgraph_weight, dim=1).unsqueeze(1).expand(l_subgraph_weight.size(0), l_subgraph_weight.size(1))
                l_subgraph_weight[l_subgraph_weight_sum != 0] = l_subgraph_weight[l_subgraph_weight_sum != 0] / l_subgraph_weight_sum[l_subgraph_weight_sum != 0]

                #pdb.set_trace()
                #filtering
                fine_selection = torch.floor(coarse_selection * 1/2)
                #visual
                v_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
                v_sub_sort_res = torch.sort(v_subgraph_weight, dim=1, descending=True)
                for i in range(0, v_is_not_pad_node.size(0)):
                    for j in range(0, int(fine_selection)):
                        v_is_not_pad_node[i][v_sub_sort_res[1][i][j]] = 1

                v_subgraph_weight = v_subgraph_weight * v_is_not_pad_node


                #label
                l_is_not_pad_node = torch.zeros((is_not_pad_node.size(0), is_not_pad_node.size(1)), requires_grad=False).cuda()
                l_sub_sort_res = torch.sort(l_subgraph_weight, dim=1, descending=True)
                for i in range(0, l_is_not_pad_node.size(0)):
                    for j in range(0, int(fine_selection)):
                        l_is_not_pad_node[i][l_sub_sort_res[1][i][j]] = 1

                l_subgraph_weight = l_subgraph_weight * l_is_not_pad_node
                #pdb.set_trace()

                #visual edge weight
                v_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, x_list[-1].size(1)):
                    ##pdb.set_trace()
                    x_ii_expand = x_list[-1][:,i,:].unsqueeze(1).expand(x_list[-1][:,i,:].size(0), x_list[-1].size(1), x_list[-1][:,i,:].size(1))
                    x_c_i = torch.cat([x_list[-1], x_ii_expand], 2)
                    x_fus_i = self.e1(x_c_i)

                    v_edge_score_i = self.e2(self.Tanh(self.l1(sentence_fus_expand) + x_fus_i)).squeeze(2)
                    v_edge_score[:,:,i] = v_edge_score_i
                
                v_edge_score = F.softmax(v_edge_score, dim = 2)
                v_edge_weight = is_not_pad_node_expand * v_edge_score

                #pdb.set_trace()
                #label edge weight
                l_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, l_list[-1].size(1)):
                    ##pdb.set_trace()
                    l_ii_expand = l_list[-1][:,i,:].unsqueeze(1).expand(l_list[-1][:,i,:].size(0), l_list[-1].size(1), l_list[-1][:,i,:].size(1))
                    l_c_i = torch.cat([l_list[-1], l_ii_expand], 2)
                    l_fus_i = self.ee1(l_c_i)

                    l_edge_score_i = self.ee2(self.Tanh(self.l1(sentence_fus_expand) + l_fus_i)).squeeze(2)
                    l_edge_score[:,:,i] = l_edge_score_i
                
                l_edge_score = F.softmax(l_edge_score, dim = 2)
                l_edge_weight = is_not_pad_node_expand * l_edge_score

                #pdb.set_trace()
                v_node_gate, v_i_feature = self.go(v_node_gate, v_subgraph_weight, x_list[-1], v_edge_weight, cls, rel)
                l_node_gate, l_i_feature = self.go(l_node_gate, l_subgraph_weight, l_list[-1], l_edge_weight, cls, rel)
                x_list.append(v_i_feature)
                l_list.append(l_i_feature)

        
        return x_list[-1], l_list[-1]

    def go(self, last_node_gate, node_weight, last_x, edge_weights, cls, rel):
        
        rel.requires_grad = False
        l_last_x = torch.matmul(last_x, self.w1)
        x3 = torch.matmul(last_x, self.w3)
        x1_t = torch.zeros((l_last_x.size(0), l_last_x.size(1), l_last_x.size(2)), requires_grad=False).cuda()

        last_node_gate_expand = last_node_gate.unsqueeze(2).expand(last_node_gate.size(0), last_node_gate.size(1), last_node_gate.size(1))
         
        for i in range(self.nrel_l):
            adj1_un = (rel == i).detach()
            adj1 = adj1_un.transpose(2, 1).float()
      
            gate_matrix_1 = edge_weights                                                                             
            gate_adj1 = gate_matrix_1 * adj1
            gate_adj1 = gate_adj1 * last_node_gate_expand
            x1_t = x1_t + torch.bmm(gate_adj1, l_last_x) + \
                                    self.rel_bias[i].unsqueeze(0).unsqueeze(1).expand(adj1.size(0),
                                                                                      adj1.size(1),
                                                                                      self.rel_bias.size(1)) * \
                                    gate_adj1.sum(2).unsqueeze(2).expand(adj1.size(0), adj1.size(1),
                                                                         self.rel_bias.size(1))


        #pdb.set_trace()
        adj1_un = (rel == i).detach()
        adj1 = adj1_un.transpose(2, 1).float()



        adj3 = torch.ones((x3.size(0), x3.size(1)), requires_grad=False).cuda()
        adj3[cls == -1] = 0.0
        adj3 = adj3.unsqueeze(2)
        adj3_weight = adj3
        x3_t = x3 * adj3_weight.expand(adj3.size(0), adj3.size(1), x3.size(2))

        x_new = F.relu(x1_t + x3_t)

        # update gate
        new_gate = node_weight
        new_gate_expand = new_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        total_gate = last_node_gate + new_gate
        total_gate_expand = total_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        x_combine = new_gate_expand * x_new + last_node_gate.unsqueeze(2).expand(-1, -1, last_x.size(2)) * last_x
        x_combine[total_gate_expand != 0] = x_combine[total_gate_expand != 0] / total_gate_expand[total_gate_expand != 0]

        return total_gate, x_combine

    def go_node(self, node_weight, x_ini):
        return node_weight, x_ini

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + '->' \
               + str(self.out_features) + ')'
