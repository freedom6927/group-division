import torch
import torch.nn as nn
from cmrin_models.model_utils import NormalizeScale
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math
import pdb


class GraphR(nn.Module):
    def __init__(self, opt):
        super(GraphR, self).__init__()

        dim_word_embed = opt['word_embedding_size']
        dim_word_output = opt['rnn_hidden_size'] * (2 if opt['bidirectional'] else 1)

        self.feat_normalizer = NormalizeScale(opt['dim_input_vis_feat'], opt['vis_init_norm'])
        self.label_normalizer = NormalizeScale(opt['rnn_hidden_size'], opt['vis_init_norm'])
        dim_input_vis_feat = opt['dim_input_vis_feat']
        self.word_normalizer = NormalizeScale(dim_word_embed, opt['word_init_norm'])

        self.nrel_l = opt['num_location_relation']
        

        self.T_ctrl = opt['T_ctrl']

        dim_reason = opt['dim_reason']
        # fusion model
        dim_fusion_input = dim_input_vis_feat + dim_word_embed
        self.fuse_fc = nn.Linear(dim_fusion_input, dim_reason)
        self.fuse_sii = nn.Linear(dim_fusion_input, dim_reason)
        self.fuse_sii_L = nn.Linear(opt['rnn_hidden_size'] + dim_word_embed, dim_reason)


        #########################################ke############################################################3
        self.Tanh = nn.Tanh()
        # visual 
        # sub,intra,inter
        self.l1 = nn.Linear(dim_word_embed, dim_word_output)
        self.l2 = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.l3 = nn.Linear(dim_word_output, 1)
        



        self.e1 = nn.Linear(dim_word_output * 2, dim_word_output)
        self.e2 = nn.Linear(dim_word_output, 1)

        self.feature_convert = nn.Linear(dim_input_vis_feat, dim_word_output)
        self.sentence_fus = nn.Linear(dim_word_embed * 3, dim_word_embed)


        #label
        self.ll1 = nn.Linear(dim_word_embed, opt['rnn_hidden_size'])
        self.ll3 = nn.Linear(opt['rnn_hidden_size'], 1)


        self.le1 = nn.Linear(opt['rnn_hidden_size'] * 2, opt['rnn_hidden_size'])
        self.le2 = nn.Linear(opt['rnn_hidden_size'], 1)

        #self.ee1 = nn.Linear(dim_word_output * 2, dim_word_output)
        #self.ee2 = nn.Linear(dim_word_output, 1)

        #self.clip_trans = nn.Linear(opt['rnn_hidden_size'], dim_input_vis_feat)

        #########################################ke############################################################3

        # update feature
        self.w1 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.w3 = Parameter(torch.FloatTensor(dim_reason, dim_reason))
        self.rel_bias = Parameter(torch.FloatTensor(self.nrel_l, dim_reason))
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.w1.size(1))
        self.w1.data.uniform_(-stdv, stdv)
        self.w3.data.uniform_(-stdv, stdv)
        self.rel_bias.data.uniform_(-stdv, stdv)

    def forward(self, visual_feature, label_feature, sub_weight, intra_weight, inter_weight, embed, cls, rel):
        #pdb.set_trace()
        #clip_feature = self.clip_trans(visual_feature)
        #x = self.feat_normalizer(clip_feature)
        x = self.feat_normalizer(visual_feature)
        L = self.label_normalizer(label_feature)
        words = self.word_normalizer(embed)
        
        #########################################ke############################################################3

        #sub, intra, inter
        sub_weight_expand = sub_weight.unsqueeze(2).expand(sub_weight.size(0), sub_weight.size(1), words.size(2))
        intra_weight_expand = intra_weight.unsqueeze(2).expand(intra_weight.size(0), intra_weight.size(1), words.size(2))
        inter_weight_expand = inter_weight.unsqueeze(2).expand(inter_weight.size(0), inter_weight.size(1), words.size(2))
        sub_vector = (sub_weight_expand * words).sum(1)
        intra_vector = (intra_weight_expand * words).sum(1)
        inter_vector = (inter_weight_expand * words).sum(1)

  
        sub_vector_expand = sub_vector.unsqueeze(1).expand(sub_vector.size(0), x.size(1), sub_vector.size(1))
        intra_vector_expand = intra_vector.unsqueeze(1).expand(intra_vector.size(0), x.size(1), intra_vector.size(1))
        inter_vector_expand = inter_vector.unsqueeze(1).expand(inter_vector.size(0), x.size(1), inter_vector.size(1))


        ##pdb.set_trace()
        sentence1 = torch.cat([sub_vector, intra_vector], 1)
        sentence2 = torch.cat([sentence1, inter_vector], 1)
        sentence_fus = self.sentence_fus(sentence2)
        sentence_fus_expand = sentence_fus.unsqueeze(1).expand(sentence_fus.size(0), x.size(1), sentence_fus.size(1))
        is_not_pad_node = (cls != -1.0).float()
            
        #########################################ke############################################################3



        # iterator
        
        x_node_gate = torch.zeros((x.size(0), x.size(1)), requires_grad=False).cuda()
        l_node_gate = torch.zeros((L.size(0), L.size(1)), requires_grad=False).cuda()
        # edge_type_gate = torch.zeros((edge_type_weight.size(0), edge_type_weight.size(2)), requires_grad=False).cuda()
        x_list = []
        l_list = []
        for i in range(self.T_ctrl):

            #########################################ke############################################################3
            if i == 0:
                # my visual node weight
                v_sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + self.l2(x))).squeeze(2)
                v_intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + self.l2(x))).squeeze(2)
                v_inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + self.l2(x))).squeeze(2)

                v_sub_weight = F.softmax(v_sub_score, dim = 1)
                v_intra_weight = F.softmax(v_intra_score, dim = 1)
                v_inter_weight = F.softmax(v_inter_score, dim = 1)

                v_sub_weight = v_sub_weight * is_not_pad_node
                v_intra_weight = v_intra_weight * is_not_pad_node
                v_inter_weight = v_inter_weight * is_not_pad_node

                v_sub_weight_sum = torch.sum(v_sub_weight, dim=1).unsqueeze(1).expand(v_sub_weight.size(0), v_sub_weight.size(1))
                v_sub_weight[v_sub_weight_sum != 0] = v_sub_weight[v_sub_weight_sum != 0] / v_sub_weight_sum[v_sub_weight_sum != 0]

                v_intra_weight_sum = torch.sum(v_intra_weight, dim=1).unsqueeze(1).expand(v_intra_weight.size(0), v_intra_weight.size(1))
                v_intra_weight[v_intra_weight_sum != 0] = v_intra_weight[v_intra_weight_sum != 0] / v_intra_weight_sum[v_intra_weight_sum != 0]

                v_inter_weight_sum = torch.sum(v_inter_weight, dim=1).unsqueeze(1).expand(v_inter_weight.size(0), v_inter_weight.size(1))
                v_inter_weight[v_inter_weight_sum != 0] = v_inter_weight[v_inter_weight_sum != 0] / v_inter_weight_sum[v_inter_weight_sum != 0]



                v_node_weight1 = torch.cat([v_sub_weight.unsqueeze(2), v_intra_weight.unsqueeze(2)], 2)
                v_node_weight_all = torch.cat([v_node_weight1, v_inter_weight.unsqueeze(2)], 2)
                v_wegiht_info = torch.max(v_node_weight_all, 2)
                v_node_weight_type = v_wegiht_info[1]
                v_i_node_weight = v_wegiht_info[0]


                #visual node defination
                v_sub_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
                v_intra_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
                v_inter_selection = torch.zeros((v_i_node_weight.size(0), v_i_node_weight.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, v_node_weight_type.size(0)):
                    for j in range(0, v_node_weight_type.size(1)):
                        if v_node_weight_type[i, j] == 0:
                            v_sub_selection[i, j] = 1
                        if v_node_weight_type[i, j] == 1:
                            v_intra_selection[i, j] = 1
                        if v_node_weight_type[i, j] == 2:
                            v_inter_selection[i, j] = 1
                
                #pdb.set_trace()
                v_sub_vector_selection = sub_vector_expand * v_sub_selection.unsqueeze(2).expand(v_sub_selection.size(0), v_sub_selection.size(1), sub_vector.size(1))
                v_intra_vector_selection = intra_vector_expand * v_intra_selection.unsqueeze(2).expand(v_intra_selection.size(0), v_intra_selection.size(1), intra_vector.size(1))
                v_inter_vector_selection = inter_vector_expand * v_inter_selection.unsqueeze(2).expand(v_inter_selection.size(0), v_inter_selection.size(1), inter_vector.size(1))
                v_vector_selection = v_sub_vector_selection + v_intra_vector_selection + v_inter_vector_selection

                x_sii = torch.cat([x, v_vector_selection], dim = 2)
                x_sii = x_sii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), x_sii.size(2)))
                x_i = self.fuse_sii(x_sii)

                #my visual edge weight
                ##pdb.set_trace()
                
                visual_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(2))).cuda()
                #pdb.set_trace()
                for i in range(0, x.size(1)):
                    ##pdb.set_trace()
                    e_x_i = self.feature_convert(x[:,i,:])
                    x_convert = self.feature_convert(x)
                    e_x_i_expand = e_x_i.unsqueeze(1).expand(e_x_i.size(0), x.size(1), e_x_i.size(1))
                    x_c_i = torch.cat([x_convert, e_x_i_expand], 2)
                    x_fus_i = self.Tanh(self.e1(x_c_i))
                    visual_edge_score_i = self.e2(x_fus_i).squeeze(2)
                    visual_edge_score[:,:,i] = visual_edge_score_i
                #pdb.set_trace()
                visual_edge_score_norm = F.softmax(visual_edge_score, dim = 2)
                is_not_pad_node_expand = is_not_pad_node.unsqueeze(1).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), is_not_pad_node.size(1))
                visual_edge_weights = visual_edge_score_norm * is_not_pad_node_expand
                x_node_gate, x_i = self.go_node(v_i_node_weight, x_i)




                # my label node weight
                l_sub_score = self.ll3(self.Tanh(self.ll1(sub_vector_expand) + L)).squeeze(2)
                l_intra_score = self.ll3(self.Tanh(self.ll1(intra_vector_expand) + L)).squeeze(2)
                l_inter_score = self.ll3(self.Tanh(self.ll1(inter_vector_expand) + L)).squeeze(2)

                l_sub_weight = F.softmax(l_sub_score, dim = 1)
                l_intra_weight = F.softmax(l_intra_score, dim = 1)
                l_inter_weight = F.softmax(l_inter_score, dim = 1)

                l_sub_weight = l_sub_weight * is_not_pad_node
                l_intra_weight = l_intra_weight * is_not_pad_node
                l_inter_weight = l_inter_weight * is_not_pad_node

                l_sub_weight_sum = torch.sum(l_sub_weight, dim=1).unsqueeze(1).expand(l_sub_weight.size(0), l_sub_weight.size(1))
                l_sub_weight[l_sub_weight_sum != 0] = l_sub_weight[l_sub_weight_sum != 0] / l_sub_weight_sum[l_sub_weight_sum != 0]

                l_intra_weight_sum = torch.sum(l_intra_weight, dim=1).unsqueeze(1).expand(l_intra_weight.size(0), l_intra_weight.size(1))
                l_intra_weight[l_intra_weight_sum != 0] = l_intra_weight[l_intra_weight_sum != 0] / l_intra_weight_sum[l_intra_weight_sum != 0]

                l_inter_weight_sum = torch.sum(l_inter_weight, dim=1).unsqueeze(1).expand(l_inter_weight.size(0), l_inter_weight.size(1))
                l_inter_weight[l_inter_weight_sum != 0] = l_inter_weight[l_inter_weight_sum != 0] / l_inter_weight_sum[l_inter_weight_sum != 0]

                l_node_weight1 = torch.cat([l_sub_weight.unsqueeze(2), l_intra_weight.unsqueeze(2)], 2)
                l_node_weight_all = torch.cat([l_node_weight1, l_inter_weight.unsqueeze(2)], 2)
                ##pdb.set_trace()
                l_wegiht_info = torch.max(l_node_weight_all, 2)
                l_node_weight_type = l_wegiht_info[1]
                l_i_node_weight = l_wegiht_info[0]


                # my label node definition

                l_sub_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
                l_intra_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
                l_inter_selection = torch.zeros((l_i_node_weight.size(0), l_i_node_weight.size(1)), requires_grad=False).cuda()
                #pdb.set_trace()
                for i in range(0, l_node_weight_type.size(0)):
                    for j in range(0, l_node_weight_type.size(1)):
                        if l_node_weight_type[i, j] == 0:
                            l_sub_selection[i, j] = 1
                        if l_node_weight_type[i, j] == 1:
                            l_intra_selection[i, j] = 1
                        if l_node_weight_type[i, j] == 2:
                            l_inter_selection[i, j] = 1

                #pdb.set_trace()
                l_sub_vector_selection = sub_vector_expand * l_sub_selection.unsqueeze(2).expand(l_sub_selection.size(0), l_sub_selection.size(1), sub_vector.size(1))
                l_intra_vector_selection = intra_vector_expand * l_intra_selection.unsqueeze(2).expand(l_intra_selection.size(0), l_intra_selection.size(1), intra_vector.size(1))
                l_inter_vector_selection = inter_vector_expand * l_inter_selection.unsqueeze(2).expand(l_inter_selection.size(0), l_inter_selection.size(1), inter_vector.size(1))
                l_vector_selection = l_sub_vector_selection + l_intra_vector_selection + l_inter_vector_selection




                l_ii = torch.cat([L, l_vector_selection], dim = 2)
                l_ii = l_ii * (is_not_pad_node.unsqueeze(2).expand(is_not_pad_node.size(0), is_not_pad_node.size(1), l_ii.size(2)))
                l_i = self.fuse_sii_L(l_ii)

                # my label edge weight

                L_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(2))).cuda()
                #pdb.set_trace()
                for i in range(0, L.size(1)):
                    ##pdb.set_trace()
                    e_L_i = L[:,i,:]
                    e_L_i_expand = e_L_i.unsqueeze(1).expand(e_L_i.size(0), L.size(1), e_L_i.size(1))
                    L_c_i = torch.cat([L, e_L_i_expand], 2)
                    L_fus_i = self.Tanh(self.le1(L_c_i))
                    L_edge_score_i = self.le2(L_fus_i).squeeze(2)
                    L_edge_score[:,:,i] = L_edge_score_i
                
                L_edge_score_norm = F.softmax(L_edge_score, dim = 2)
                label_edge_weights = L_edge_score_norm * is_not_pad_node_expand
                l_node_gate, l_i = self.go_node(l_i_node_weight, l_i)
                #pdb.set_trace()
            #########################################ke############################################################3
            else:
                if i == 1:
                    v_node_gate, x_i = self.go(x_node_gate, v_i_node_weight, x_i, visual_edge_weights, cls, rel)
                    l_node_gate, l_i = self.go(l_node_gate, l_i_node_weight, l_i, label_edge_weights, cls, rel)

                else:
                    #########################################ke############################################################3
                    #my visual node weight
                    #pdb.set_trace()
                    v_sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + x_i)).squeeze(2)
                    v_intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + x_i)).squeeze(2)
                    v_inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + x_i)).squeeze(2)

                    v_sub_weight = F.softmax(v_sub_score, dim = 1)
                    v_intra_weight = F.softmax(v_intra_score, dim = 1)
                    v_inter_weight = F.softmax(v_inter_score, dim = 1)

                    v_sub_weight = v_sub_weight * is_not_pad_node
                    v_intra_weight = v_intra_weight * is_not_pad_node
                    v_inter_weight = v_inter_weight * is_not_pad_node

                    v_sub_weight_sum = torch.sum(v_sub_weight, dim=1).unsqueeze(1).expand(v_sub_weight.size(0), v_sub_weight.size(1))
                    v_sub_weight[v_sub_weight_sum != 0] = v_sub_weight[v_sub_weight_sum != 0] / v_sub_weight_sum[v_sub_weight_sum != 0]

                    v_intra_weight_sum = torch.sum(v_intra_weight, dim=1).unsqueeze(1).expand(v_intra_weight.size(0), v_intra_weight.size(1))
                    v_intra_weight[v_intra_weight_sum != 0] = v_intra_weight[v_intra_weight_sum != 0] / v_intra_weight_sum[v_intra_weight_sum != 0]

                    v_inter_weight_sum = torch.sum(v_inter_weight, dim=1).unsqueeze(1).expand(v_inter_weight.size(0), v_inter_weight.size(1))
                    v_inter_weight[v_inter_weight_sum != 0] = v_inter_weight[v_inter_weight_sum != 0] / v_inter_weight_sum[v_inter_weight_sum != 0]

                    v_node_weight1 = torch.cat([v_sub_weight.unsqueeze(2), v_intra_weight.unsqueeze(2)], 2)
                    v_node_weight_all = torch.cat([v_node_weight1, v_inter_weight.unsqueeze(2)], 2)
                    ##pdb.set_trace()
                    v_wegiht_info = torch.max(v_node_weight_all, 2)
                    v_i_node_weight = v_wegiht_info[0]
                    
                    #my label node weight
                    l_sub_score = self.l3(self.Tanh(self.l1(sub_vector_expand) + l_i)).squeeze(2)
                    l_intra_score = self.l3(self.Tanh(self.l1(intra_vector_expand) + l_i)).squeeze(2)
                    l_inter_score = self.l3(self.Tanh(self.l1(inter_vector_expand) + l_i)).squeeze(2)

                    l_sub_weight = F.softmax(l_sub_score, dim = 1)
                    l_intra_weight = F.softmax(l_intra_score, dim = 1)
                    l_inter_weight = F.softmax(l_inter_score, dim = 1)

                    l_sub_weight = l_sub_weight * is_not_pad_node
                    l_intra_weight = l_intra_weight * is_not_pad_node
                    l_inter_weight = l_inter_weight * is_not_pad_node

                    l_sub_weight_sum = torch.sum(l_sub_weight, dim=1).unsqueeze(1).expand(l_sub_weight.size(0), l_sub_weight.size(1))
                    l_sub_weight[l_sub_weight_sum != 0] = l_sub_weight[l_sub_weight_sum != 0] / l_sub_weight_sum[l_sub_weight_sum != 0]

                    l_intra_weight_sum = torch.sum(l_intra_weight, dim=1).unsqueeze(1).expand(l_intra_weight.size(0), l_intra_weight.size(1))
                    l_intra_weight[l_intra_weight_sum != 0] = l_intra_weight[l_intra_weight_sum != 0] / l_intra_weight_sum[l_intra_weight_sum != 0]

                    l_inter_weight_sum = torch.sum(l_inter_weight, dim=1).unsqueeze(1).expand(l_inter_weight.size(0), l_inter_weight.size(1))
                    l_inter_weight[l_inter_weight_sum != 0] = l_inter_weight[l_inter_weight_sum != 0] / l_inter_weight_sum[l_inter_weight_sum != 0]

                    l_node_weight1 = torch.cat([l_sub_weight.unsqueeze(2), l_intra_weight.unsqueeze(2)], 2)
                    l_node_weight_all = torch.cat([l_node_weight1, l_inter_weight.unsqueeze(2)], 2)
                    ##pdb.set_trace()
                    l_wegiht_info = torch.max(l_node_weight_all, 2)
                    l_i_node_weight = l_wegiht_info[0]


                    #my visual_edge weight
                    v_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                    #pdb.set_trace()
                    for i in range(0, x.size(1)):
                        ##pdb.set_trace()
                        x_ii_expand = x_i[:,i,:].unsqueeze(1).expand(x_i[:,i,:].size(0), x_i.size(1), x_i[:,i,:].size(1))
                        x_c_i = torch.cat([x_i, x_ii_expand], 2)
                        x_fus_i = self.e1(x_c_i)

                        v_edge_score_i = self.e2(self.Tanh(self.l1(sentence_fus_expand) + x_fus_i)).squeeze(2)
                        v_edge_score[:,:,i] = v_edge_score_i
                    
                    v_edge_score = F.softmax(v_edge_score, dim = 2)
                    v_edge_weight = is_not_pad_node_expand * v_edge_score
                    
                    v_node_gate, x_i = self.go(v_node_gate, v_i_node_weight, x_i, v_edge_weight, cls, rel)

                    #pdb.set_trace()
                    #my label_edge weight
                    l_edge_score = torch.zeros((rel.size(0), rel.size(1), rel.size(1)), requires_grad=False).cuda()
                    for i in range(0, L.size(1)):
                        ##pdb.set_trace()
                        l_ii_expand = l_i[:,i,:].unsqueeze(1).expand(l_i[:,i,:].size(0), l_i.size(1), l_i[:,i,:].size(1))
                        #pdb.set_trace()
                        l_c_i = torch.cat([l_i, l_ii_expand], 2)
                        l_fus_i = self.e1(l_c_i)

                        l_edge_score_i = self.e2(self.Tanh(self.l1(sentence_fus_expand) + l_fus_i)).squeeze(2)
                        l_edge_score[:,:,i] = l_edge_score_i
                    
                    l_edge_score = F.softmax(l_edge_score, dim = 2)
                    l_edge_weights = is_not_pad_node_expand * l_edge_score
                    l_node_gate, l_i = self.go(l_node_gate, l_i_node_weight, l_i, l_edge_weights, cls, rel)
                    #pdb.set_trace()
                    #########################################ke############################################################3

            x_list.append(x_i)
            l_list.append(l_i)

        return x_list[-1], l_list[-1]

    def go(self, last_node_gate, node_weight, last_x, edge_weights, cls, rel):
        
        rel.requires_grad = False
        l_last_x = torch.matmul(last_x, self.w1)
        x3 = torch.matmul(last_x, self.w3)
        x1_t = torch.zeros((l_last_x.size(0), l_last_x.size(1), l_last_x.size(2)), requires_grad=False).cuda()

        last_node_gate_expand = last_node_gate.unsqueeze(2).expand(last_node_gate.size(0), last_node_gate.size(1), last_node_gate.size(1))
         
        for i in range(self.nrel_l):
            adj1_un = (rel == i).detach()
            adj1 = adj1_un.transpose(2, 1).float()
      
            gate_matrix_1 = edge_weights                                                                             
            gate_adj1 = gate_matrix_1 * adj1
            gate_adj1 = gate_adj1 * last_node_gate_expand
            x1_t = x1_t + torch.bmm(gate_adj1, l_last_x) + \
                                    self.rel_bias[i].unsqueeze(0).unsqueeze(1).expand(adj1.size(0),
                                                                                      adj1.size(1),
                                                                                      self.rel_bias.size(1)) * \
                                    gate_adj1.sum(2).unsqueeze(2).expand(adj1.size(0), adj1.size(1),
                                                                         self.rel_bias.size(1))


        #pdb.set_trace()
        adj1_un = (rel == i).detach()
        adj1 = adj1_un.transpose(2, 1).float()



        adj3 = torch.ones((x3.size(0), x3.size(1)), requires_grad=False).cuda()
        adj3[cls == -1] = 0.0
        adj3 = adj3.unsqueeze(2)
        adj3_weight = adj3
        x3_t = x3 * adj3_weight.expand(adj3.size(0), adj3.size(1), x3.size(2))

        x_new = F.relu(x1_t + x3_t)

        # update gate
        new_gate = node_weight
        new_gate_expand = new_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        total_gate = last_node_gate + new_gate
        total_gate_expand = total_gate.unsqueeze(2).expand(-1, -1, x1_t.size(2))
        x_combine = new_gate_expand * x_new + last_node_gate.unsqueeze(2).expand(-1, -1, last_x.size(2)) * last_x
        x_combine[total_gate_expand != 0] = x_combine[total_gate_expand != 0] / total_gate_expand[total_gate_expand != 0]

        return total_gate, x_combine

    def go_node(self, node_weight, x_ini):
        return node_weight, x_ini

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + '->' \
               + str(self.out_features) + ')'
